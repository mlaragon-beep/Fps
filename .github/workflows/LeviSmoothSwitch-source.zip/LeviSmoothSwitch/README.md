# Levi SmoothSwitch — Diagnostic Baseline

Target: LeviLauncher / Minecraft Bedrock 1.26.60.4, ARM64.

This is a **native-mod loader/build baseline**, not yet a hotbar-lag fix. It registers
a harmless mod and writes lifecycle messages through the Preloader logger. It does
not install hooks, patch memory, alter rendering, or claim to improve performance.

## Why this first build exists

The supplied SDK exposes generic native hook/signature APIs, but the supplied files
do not identify a verified Minecraft 1.26.60.4 function/signature for held-item
rendering or resource reload. Installing guessed hooks could crash the game.
First confirm that this SDK + package template loads on the target launcher/build.

## Build from an Android tablet using GitHub Actions

1. Create a GitHub account if you do not already have one.
2. In GitHub, create a **new private repository** named `LeviSmoothSwitch`.
3. Upload the contents of this ZIP (not the enclosing ZIP file) to the repository's
   `main` branch. Keep `.github/workflows/build.yml` and all folders.
4. Open the repository's **Actions** tab and enable workflows if GitHub asks.
5. Select **Build** → **Run workflow**. Alternatively, a push to `main` starts it.
6. Wait for the workflow to finish. Open the completed run and download the artifact
   named `levi-smoothswitch-android-mod-template`.
7. Inside the downloaded artifact, locate the ARM64 `.levipack`. Import it into
   LeviLauncher only after checking that the workflow succeeded.

GitHub Actions performs the compilation in the cloud; Android Studio, NDK, CMake,
and Ninja do not need to be installed on the tablet.

## Build details

- Preloader Android SDK tag: `0.2.3`
- Android ABI: `arm64-v8a` and `armeabi-v7a` (workflow template builds both)
- Android platform: 28
- NDK: 28.2.13676358
- Manifest target: `1.26.60.4`

## Next development gate

After the baseline loads successfully, collect logs and verify the runtime version.
Only then should a separate, version-verified rendering investigation be added.
Do not use generic signatures or offsets from another Minecraft build.
