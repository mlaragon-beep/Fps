#include "mod/MyMod.h"

#include <filesystem>

#include <pl/Mod.hpp>

namespace levi_smoothswitch {

SmoothSwitchMod &SmoothSwitchMod::instance() {
    static SmoothSwitchMod instance;
    return instance;
}

SmoothSwitchMod::SmoothSwitchMod() : mSelf(*ll::mod::NativeMod::current()) {}

bool SmoothSwitchMod::load() {
    auto &self = getSelf();
    self.getLogger().debug("Loading Levi SmoothSwitch diagnostic baseline...");

    std::error_code ec;
    std::filesystem::create_directories(self.getDataDir(), ec);
    if (ec) {
        self.getLogger().error("Failed to create data directory {}: {}", self.getDataDir().string(),
                               ec.message());
        return false;
    }

    std::filesystem::create_directories(self.getConfigDir(), ec);
    if (ec) {
        self.getLogger().error("Failed to create config directory {}: {}",
                               self.getConfigDir().string(), ec.message());
        return false;
    }

    mConfigFile.emplace();
    if (!mConfigFile->load()) {
        self.getLogger().warn("Failed to load typed config");
        return false;
    }
    mConfig = mConfigFile->value();

    self.getLogger().info("Loaded {} from {}", self.getName(), self.getModDir().string());
    return true;
}

bool SmoothSwitchMod::enable() {
    auto &self = getSelf();
    self.getLogger().debug("Enabling diagnostic baseline...");
    if (!mConfig.enabled) {
        self.getLogger().info("levi_smoothswitch diagnostics disabled by config");
        return true;
    }

    self.getLogger().info("Diagnostic: {}", mConfig.message);
    return true;
}

bool SmoothSwitchMod::disable() {
    getSelf().getLogger().debug("Disabling diagnostic baseline...");
    // Undo enable-time state here.
    return true;
}

bool SmoothSwitchMod::unload() {
    getSelf().getLogger().debug("Unloading diagnostic baseline...");
    // Release load-time resources here.
    mConfigFile.reset();
    return true;
}

} // namespace levi_smoothswitch
