#pragma once

#include <string>
#include <string_view>

#include <pl/Config.hpp>

namespace levi_smoothswitch {

struct ModConfig {
    int version = 1;
    bool enabled = true;
    std::string message = "Levi SmoothSwitch diagnostic baseline";
};

nlohmann::json makeDefaultConfigJson();
nlohmann::json makeConfigSchemaJson();

} // namespace levi_smoothswitch

template <> struct pl::config::Schema<levi_smoothswitch::ModConfig> {
    static constexpr std::string_view title = "Levi SmoothSwitch Config";
    static constexpr std::string_view description = {};

    static constexpr FieldSchema field(std::string_view name) {
        if (name == "version")
            return {.title = "Version", .readOnly = true};
        if (name == "enabled")
            return {.title = "Enabled", .description = "Turns levi_smoothswitch behavior on or off."};
        if (name == "message")
            return {.title = "Message", .description = "Message written when the mod is enabled."};
        return {};
    }
};
