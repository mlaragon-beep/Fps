#include "mod/MyMod.h"

#include <pl/Mod.hpp>

PL_REGISTER_MOD(levi_smoothswitch::SmoothSwitchMod, levi_smoothswitch::SmoothSwitchMod::instance());
