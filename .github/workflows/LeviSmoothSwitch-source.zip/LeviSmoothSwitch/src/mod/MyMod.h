#pragma once

#include <optional>

#include "mod/Config.h"

#include <pl/Mod.hpp>

namespace levi_smoothswitch {

class SmoothSwitchMod {
  public:
    static SmoothSwitchMod &instance();

    SmoothSwitchMod();

    [[nodiscard]] ll::mod::NativeMod &getSelf() const { return mSelf; }

    bool load();
    bool enable();
    bool disable();
    bool unload();

  private:
    ll::mod::NativeMod &mSelf;
    ModConfig mConfig;
    std::optional<pl::config::ConfigFile<ModConfig>> mConfigFile;
};

} // namespace levi_smoothswitch
